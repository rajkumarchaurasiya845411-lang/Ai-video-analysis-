import express from "express";
import cors from "cors";
import { z } from "zod";
import crypto from "node:crypto";

const app = express();
app.use(cors());
app.use(express.json({ limit: "64kb" }));

const RequestSchema = z.object({
  referenceUrl: z.string().url(),
  instruction: z.string().min(5).max(3000),
  outputType: z.enum(["full_video"]).default("full_video"),
  style: z.enum(["Cinematic", "Vlog", "YouTube Shorts"]).default("Cinematic")
});

function validateYoutubeUrl(raw) {
  const u = new URL(raw);
  const host = u.hostname.toLowerCase().replace(/^www\\./, "");
  if (!["youtube.com", "m.youtube.com", "youtu.be", "youtube-nocookie.com"].includes(host)) {
    throw new Error("Please provide a YouTube URL.");
  }
  return u.toString();
}

/**
 * This provider-independent creative plan is real output from this backend.
 * It does NOT claim to have watched the referenced video or rendered a video.
 * Configure a video generation provider in renderVideo() to create a real MP4.
 */
function makeCreativePlan({ instruction, style }) {
  const isShort = style === "YouTube Shorts";
  const durationSeconds = isShort ? 35 : style === "Vlog" ? 90 : 60;
  return {
    title: "Original video based on your brief",
    durationSeconds,
    aspectRatio: isShort ? "9:16" : "16:9",
    language: "Follow the language requested in the user's instruction; default to Hindi if unspecified.",
    voice: "Warm, clear Hindi voice-over; generate only after the user approves the script.",
    music: "Original royalty-free instrumental background track, mixed below narration.",
    originality: "Use the reference only for high-level inspiration. Do not copy its script, footage, branding, or music.",
    scenes: [
      {
        seconds: isShort ? 0 : 0,
        visual: "Opening hook: a striking original visual that introduces the topic; no copied frames or logos.",
        narration: "Start with a short, curiosity-building line that matches the user's topic.",
        onScreenText: "A strong opening hook",
        audio: "Short original sound accent, then low background music"
      },
      {
        seconds: isShort ? 8 : 15,
        visual: "Show the key idea with original generated footage or licensed stock visuals.",
        narration: "Explain the first key point in simple language with natural pacing.",
        onScreenText: "Key point 1",
        audio: "Voice-forward mix with subtle original music"
      },
      {
        seconds: isShort ? 18 : 35,
        visual: "Use a second visual angle, example, or concise demonstration to keep the video moving.",
        narration: "Give an example or reveal that supports the topic.",
        onScreenText: "Example / reveal",
        audio: "Light transition sound"
      },
      {
        seconds: isShort ? 28 : 48,
        visual: "Finish with a clear takeaway and a clean end card.",
        narration: "Summarize the takeaway and add a suitable call to action if requested.",
        onScreenText: "Takeaway",
        audio: "Music fades out cleanly"
      }
    ]
  };
}

async function renderVideo({ referenceUrl, instruction, style, creativePlan }) {
  // PROVIDER INTEGRATION POINT:
  // 1) Send prompt/storyboard to your chosen video-generation provider from server-side code.
  // 2) Generate visual clips, voice-over and original/cleared music.
  // 3) Assemble/mix clips with FFmpeg in a background job.
  // 4) Store the MP4 in private object storage and return a signed HTTPS URL.
  //
  // Do not download/reuse the reference video's full footage or audio without permission.
  // Do not put provider secrets in the Android app.
  //
  // Until a provider is configured, return null so the API is honest about its status.
  return null;
}

app.get("/health", (_req, res) => res.json({ ok: true, service: "AI Video Checker backend" }));

app.post("/api/generate", async (req, res) => {
  const parsed = RequestSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({
      error: "Invalid request. Provide a YouTube URL, an instruction of 5–3000 characters, and a supported style."
    });
  }

  let referenceUrl;
  try {
    referenceUrl = validateYoutubeUrl(parsed.data.referenceUrl);
  } catch {
    return res.status(400).json({ error: "Please provide a valid YouTube URL." });
  }

  const { instruction, style } = parsed.data;
  const creativePlan = makeCreativePlan({ instruction, style });
  const jobId = crypto.randomUUID();

  try {
    const outputUrl = await renderVideo({
      referenceUrl, instruction, style, creativePlan
    });

    if (outputUrl) {
      return res.status(200).json({
        status: "completed",
        message: "Video generation completed.",
        jobId,
        creativePlan,
        outputUrl
      });
    }

    return res.status(202).json({
      status: "plan_ready",
      message: "Creative plan generated. Real video rendering is not enabled yet; configure renderVideo() with a video provider and a voice/music pipeline.",
      jobId,
      creativePlan,
      outputUrl: null
    });
  } catch (error) {
    console.error("Generation error:", error);
    return res.status(502).json({ error: "The video provider failed. Try again later." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () => {
  console.log(`AI Video Checker backend listening on port ${port}`);
});
