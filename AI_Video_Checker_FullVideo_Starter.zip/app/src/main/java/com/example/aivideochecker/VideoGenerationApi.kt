package com.example.aivideochecker

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Calls your own backend. Never put a provider API key in the Android app.
 * Replace BASE_URL with your deployed HTTPS backend URL.
 */
object VideoGenerationApi {
    private const val BASE_URL = "https://YOUR_BACKEND_DOMAIN.example"

    fun generatePlan(referenceUrl: String, instruction: String, style: String): String {
        val url = URL("$BASE_URL/api/generate")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 90_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
        }
        try {
            val body = JSONObject()
                .put("referenceUrl", referenceUrl)
                .put("instruction", instruction)
                .put("outputType", "full_video")
                .put("style", style)
                .toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) {
                val message = try { JSONObject(response).optString("error", "Backend request failed ($code)") }
                              catch (_: Exception) { "Backend request failed ($code)" }
                throw IllegalStateException(message)
            }
            val json = JSONObject(response)
            return buildString {
                append(json.optString("status", "accepted").uppercase())
                append("\\n\\n")
                append(json.optString("message", "Request accepted."))
                val jobId = json.optString("jobId")
                if (jobId.isNotBlank() && jobId != "null") append("\\n\\nJob ID: ").append(jobId)
                val plan = json.optJSONObject("creativePlan")
                if (plan != null) {
                    append("\\n\\nVIDEO PLAN\\n")
                    append("Title: ").append(plan.optString("title")).append("\\n")
                    append("Duration: ").append(plan.optString("durationSeconds")).append(" sec\\n")
                    append("Voice: ").append(plan.optString("voice")).append("\\n")
                    append("Music: ").append(plan.optString("music")).append("\\n")
                    val scenes = plan.optJSONArray("scenes")
                    if (scenes != null) {
                        for (i in 0 until scenes.length()) {
                            val scene = scenes.optJSONObject(i) ?: continue
                            append("\\nScene ").append(i + 1).append(": ")
                                .append(scene.optString("visual")).append("\\n")
                            append("Narration: ").append(scene.optString("narration")).append("\\n")
                        }
                    }
                }
                val outputUrl = json.optString("outputUrl")
                if (outputUrl.startsWith("https://")) append("\\n\\nVideo URL: ").append(outputUrl)
            }
        } finally {
            connection.disconnect()
        }
    }
}
