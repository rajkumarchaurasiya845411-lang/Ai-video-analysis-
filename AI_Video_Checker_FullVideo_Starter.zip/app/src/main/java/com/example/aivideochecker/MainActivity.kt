package com.example.aivideochecker

import android.content.ContentResolver
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.TipsAndUpdates
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private val Bg = Color(0xFF090914)
private val Panel = Color(0xFF19172B)
private val Purple = Color(0xFFB56CFF)
private val Pink = Color(0xFFFF76C8)
private val SoftText = Color(0xFFC7C4D8)

data class VideoReport(
    val name: String,
    val durationSeconds: Long?,
    val width: Int?,
    val height: Int?,
    val hasAudio: Boolean?,
    val score: Int,
    val findings: List<String>,
    val tips: List<String>
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Purple,
                background = Bg,
                surface = Panel,
                onBackground = Color.White,
                onSurface = Color.White
            )) {
                VideoCheckerApp(
                    onAnalyze = { uri, name, callback ->
                        lifecycleScope.launch {
                            val result = withContext(Dispatchers.IO) {
                                analyzeVideo(contentResolver, uri, name)
                            }
                            callback(result)
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun VideoCheckerApp(onAnalyze: (Uri, String, (VideoReport) -> Unit) -> Unit) {
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedName by remember { mutableStateOf("") }
    var report by remember { mutableStateOf<VideoReport?>(null) }
    var isAnalyzing by remember { mutableStateOf(false) }
    var videoLink by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("Is reference video jaisa pacing aur structure rakho, lekin original script, visuals aur music banao.") }
    var channelConnected by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            selectedUri = uri
            selectedName = uri.lastPathSegment?.substringAfterLast('/') ?: "Selected video"
            report = null
            status = null
        }
    }

    Surface(Modifier.fillMaxSize(), color = Bg) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(54.dp).background(
                        Brush.linearGradient(listOf(Purple, Pink)),
                        RoundedCornerShape(17.dp)
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.PlayCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(34.dp))
                }
                Column(Modifier.padding(start = 12.dp)) {
                    Text("AI Video Checker", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Analyze • Learn • Create", color = SoftText)
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    Modifier.background(Brush.linearGradient(listOf(Color(0xFF30204A), Panel)))
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Make your next video better", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text("Video ki kami samjho aur apne original content ko improve karo.", color = SoftText)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FeatureChip("Video review")
                        FeatureChip("AI ideas")
                    }
                }
            }

            SectionTitle("1. Analyze your video")
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Gallery se video select karo", fontWeight = FontWeight.SemiBold)
                    Text("Resolution, duration, audio track aur sampled frame ki basic checks.", color = SoftText)
                    Button(onClick = { picker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.CloudUpload, contentDescription = null)
                        Text("  Select Video")
                    }
                    if (selectedUri != null) {
                        Text("Selected: $selectedName", color = Purple)
                        Button(
                            onClick = {
                                val uri = selectedUri
                                if (uri != null) {
                                    isAnalyzing = true
                                    onAnalyze(uri, selectedName) { result ->
                                        report = result
                                        isAnalyzing = false
                                    }
                                }
                            },
                            enabled = !isAnalyzing,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (isAnalyzing) "Analyzing…" else "Analyze Video")
                        }
                    }
                    if (isAnalyzing) CircularProgressIndicator(color = Purple)
                }
            }
            report?.let { ReportView(it) }

            SectionTitle("2. Reference video link")
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("YouTube ya public video link paste karo", fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = videoLink,
                        onValueChange = { videoLink = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("https://youtu.be/...") },
                        leadingIcon = { Icon(Icons.Default.Link, contentDescription = null) },
                        singleLine = true
                    )
                    Text("AI ko kya banana hai?", fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        label = { Text("Instruction, topic, language, mood…") }
                    )
                    Text("Video style", fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Cinematic", "Vlog", "YouTube Shorts").forEach { style ->
                            FilterChip(
                                selected = videoStyle == style,
                                onClick = { videoStyle = style },
                                label = { Text(style) }
                            )
                        }
                    }
                    Button(
                        onClick = {
                            if (!videoLink.startsWith("https://") ||
                                !(videoLink.contains("youtube.com") || videoLink.contains("youtu.be"))) {
                                status = "Valid YouTube URL paste karo."
                            } else if (prompt.isBlank()) {
                                status = "AI ko instruction do, jaise: Hindi mein 30-second space facts video banao."
                            } else {
                                generationBusy = true
                                status = "Backend se request bhej rahe hain…"
                                kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                                    val result = try {
                                        VideoGenerationApi.generatePlan(videoLink, prompt, videoStyle)
                                    } catch (e: Exception) {
                                        "Request nahi ja saki: ${e.message ?: "network error"}. VideoGenerationApi.kt mein apne deployed HTTPS backend ka URL set karo, phir backend deploy karo."
                                    }
                                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                        status = result
                                        generationBusy = false
                                    }
                                }
                            }
                        },
                        enabled = !generationBusy,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.PlayCircle, contentDescription = null)
                        Text(if (generationBusy) "  Creating plan…" else "  Create video with AI")
                    }
                    status?.let { Text(it, color = SoftText) }
                    Text(
                        "Backend required. This starter sends a secure-server request; actual video rendering works only after a compatible generation provider is configured on the backend.",
                        color = SoftText,
                        fontSize = 12.sp
                    )
                }
            }

            SectionTitle("3. YouTube channel")
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Connect your channel", fontWeight = FontWeight.SemiBold)
                    Text("Channel connect karne par future version mein aapke authorized videos aur analytics dikh sakte hain.", color = SoftText)
                    OutlinedButton(
                        onClick = {
                            channelConnected = !channelConnected
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (channelConnected) "Demo: Connected (not real OAuth)" else "Connect YouTube (demo)")
                    }
                    if (channelConnected) {
                        Text("Demo status only. Real account connection needs Google OAuth consent and YouTube Data API setup.", color = Pink)
                    } else {
                        Text("Abhi Google login/API connection configured nahi hai.", color = SoftText, fontSize = 12.sp)
                    }
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle("What this version can do")
                    Bullet("Select a local video")
                    Bullet("Read resolution, duration and audio metadata")
                    Bullet("Estimate a basic technical score")
                    Bullet("Paste a reference link and write a creative brief")
                    Divider(color = Color(0xFF38334F))
                    Text(
                        "Transparent limitation: real YouTube account access, AI understanding of the reference, and actual video generation are not active yet. They require secure OAuth/API integration and a video-generation service. Never put private API keys directly in the Android app.",
                        color = SoftText,
                        fontSize = 12.sp
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
fun FeatureChip(text: String) {
    Surface(color = Color(0xFF47305F), shape = RoundedCornerShape(50)) {
        Text(text, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = Color.White, fontSize = 12.sp)
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Purple)
}

@Composable
fun Bullet(text: String) {
    Row(verticalAlignment = Alignment.Top) {
        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Purple)
        Text(text, modifier = Modifier.padding(start = 8.dp), color = SoftText)
    }
}

@Composable
fun ReportView(report: VideoReport) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Analysis report", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(report.name, color = SoftText)
            Text("${report.score}/100", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Purple)
            Text("Basic technical score—not a full AI quality rating.", color = SoftText)
            Divider(color = Color(0xFF38334F))
            Text("Resolution: ${report.width ?: "Unknown"} × ${report.height ?: "Unknown"}")
            Text("Duration: ${report.durationSeconds?.let { formatDuration(it) } ?: "Unknown"}")
            Text("Audio track: ${when (report.hasAudio) { true -> "Detected"; false -> "Not detected"; else -> "Unknown" }}")
            Text("Possible issues", fontWeight = FontWeight.Bold, color = Purple)
            report.findings.forEach { Bullet(it) }
            Text("Suggestions", fontWeight = FontWeight.Bold, color = Purple)
            report.tips.forEach { Bullet(it) }
        }
    }
}

private fun analyzeVideo(resolver: ContentResolver, uri: Uri, name: String): VideoReport {
    val retriever = MediaMetadataRetriever()
    var width: Int? = null
    var height: Int? = null
    var duration: Long? = null
    var hasAudio: Boolean? = null
    val findings = mutableListOf<String>()
    val tips = mutableListOf<String>()
    var score = 100
    try {
        resolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
            retriever.setDataSource(afd.fileDescriptor)
        } ?: throw IllegalStateException("Could not open video")
        width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()
        height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()
        duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?.div(1000)
        hasAudio = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) == "yes"

        val minDimension = minOf(width ?: 0, height ?: 0)
        if (minDimension in 1..479) {
            score -= 25
            findings.add("Low video resolution detected.")
            tips.add("Try exporting at 720p or 1080p for a clearer picture.")
        } else if (minDimension == 0) {
            findings.add("Resolution could not be read.")
            tips.add("Try a standard MP4 video if details are missing.")
        }
        if (duration != null && duration < 10) {
            score -= 5
            findings.add("This is a very short clip.")
            tips.add("Make sure the clip has enough context for its purpose.")
        }
        if (duration != null && duration > 600) {
            score -= 5
            findings.add("Video is longer than 10 minutes.")
            tips.add("Consider trimming pauses where appropriate.")
        }
        if (hasAudio == false) {
            score -= 15
            findings.add("No audio track was detected.")
            tips.add("If narration or music is needed, add clear audio.")
        }
        val frame: Bitmap? = retriever.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        if (frame != null) {
            var sum = 0L
            var count = 0
            val stepX = (frame.width / 10).coerceAtLeast(1)
            val stepY = (frame.height / 10).coerceAtLeast(1)
            var y = 0
            while (y < frame.height) {
                var x = 0
                while (x < frame.width) {
                    val p = frame.getPixel(x, y)
                    val r = (p shr 16) and 255
                    val g = (p shr 8) and 255
                    val b = p and 255
                    sum += (r * 299L + g * 587L + b * 114L) / 1000L
                    count++
                    x += stepX
                }
                y += stepY
            }
            val brightness = if (count > 0) sum / count else 128L
            if (brightness < 45) {
                score -= 10
                findings.add("The sampled frame looks very dark.")
                tips.add("Check lighting and exposure; only one frame is sampled.")
            } else if (brightness > 235) {
                score -= 5
                findings.add("The sampled frame looks very bright.")
                tips.add("Check whether highlights are overexposed.")
            }
            frame.recycle()
        }
        if (findings.isEmpty()) findings.add("No major issue found by these basic checks.")
        if (tips.isEmpty()) {
            tips.add("Review story, framing, pacing, and audience fit manually.")
            tips.add("Consider a clear opening and readable captions if suitable.")
        }
    } catch (_: Exception) {
        findings.add("Some video metadata could not be read.")
        tips.add("Try another video or export it as a standard MP4.")
        score = 50
    } finally {
        try { retriever.release() } catch (_: Exception) {}
    }
    return VideoReport(name, duration, width, height, hasAudio, score.coerceIn(0, 100), findings, tips)
}

private fun formatDuration(seconds: Long): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%d:%02d", m, s)
}
