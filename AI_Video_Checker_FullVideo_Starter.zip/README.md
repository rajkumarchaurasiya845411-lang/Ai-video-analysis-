# AI Video Checker — Android + backend starter

## Implemented in this code package
- Improved dark creator-focused Android UI.
- Local video technical checks.
- Reference YouTube URL + user instruction + style selector.
- Android app sends a JSON request to your own backend over HTTPS.
- Node.js backend validates the request and returns a structured storyboard/creative plan.
- Backend has an explicit `renderVideo()` integration point for a real video provider.

## Important: actual MP4 generation is not switched on
The backend currently returns `status: plan_ready` and a storyboard. It does **not** claim to have watched the referenced video, generated voice/music, or rendered an MP4. To produce a real video, choose a provider and implement `renderVideo()` plus a voice-over, original/cleared music, FFmpeg assembly, job status polling, and secure output storage. Provider APIs, pricing, access, and content restrictions vary.

## Android setup
1. Open this folder in Android Studio (JDK 17).
2. In `app/src/main/java/com/example/aivideochecker/VideoGenerationApi.kt`, replace `https://YOUR_BACKEND_DOMAIN.example` with your deployed HTTPS backend URL.
3. Build and run on a phone. Do not use an HTTP URL in production.

## Backend setup
Requires Node.js 20+.
1. `cd backend`
2. `npm install`
3. `npm start`
4. Test health endpoint: `GET /health`
5. POST JSON to `/api/generate`:
   {
     "referenceUrl": "https://youtu.be/example",
     "instruction": "Hindi mein 30-second science facts video banao",
     "outputType": "full_video",
     "style": "YouTube Shorts"
   }

For local testing, Android emulator's host machine is usually `10.0.2.2`, but Android cleartext HTTP is disabled by default. Prefer deploying the backend to HTTPS rather than weakening app network security.

## YouTube channel connection
This is separate from reference URL generation. Real channel connection requires Google OAuth consent, a configured Google Cloud project, YouTube Data API scopes, and secure token handling. The existing UI button is a demo only.

## Safety and originality
Use the reference for high-level inspiration and only process data you are authorized to use. Do not copy another creator's complete footage, voice, script, or music. Generate original visuals, narration, and music or use assets you have permission to use. Keep API secrets on the backend.
